package ema_08_.betterGson.jTemplate;

import java.util.function.Function;

import com.google.gson.*;

import ema_08_.betterGson.JsonTypes;
import ema_08_.betterGson.exceptions.JsonTemplateValidationException;

/**
 * Default implementation of {@link JsonElementTemplate} for {@link JsonTypes#ARRAY JsonArray}s.
 */
public final class JsonArrayTemplate extends JsonElementTemplate {
	
	private final int minLen, maxLen;
	private final Function<Integer, JsonElementTemplate> templatesSupplier;
	
	/**
	 * Constructs a new template with the type {@link JsonTypes#ARRAY JsonArray} and the given parameters.
	 * 
	 * @param name This template's name, if {@code null} a default one will be used. The name is mainly
	 * 		used for identification.
	 * @param minLen The minimum (inclusive) length that the array shall have. Must be positive or {@code 0}.
	 * 		Set to {@code -1} to disable this check. If not set implicitely defaults to {@code 0}.
	 * @param maxLen The maximum (inclusive) length that the array shall have. Must be positive or {@code 0},
	 * 		and greater or equal to the minimum length if the said is different from {@code -1}.
	 * 		Set to {@code -1} to disable this check. If not set implicitely defaults to {@link Integer#MAX_VALUE}.
	 * @param templatesSupplier A function that given an index, granted to be between the minimum and maximum length
	 * 		(either given or defaults) returns a {@link JsonElementTemplate} which the array element at that index
	 * 		shall adhere to. If the function returns {@code null} then any elemnt is acceptable for such index.
	 * 		If the function is {@code null} then no check of such kind will be executed.
	 */
	public JsonArrayTemplate(String name, int minLen, int maxLen,
			Function<Integer, JsonElementTemplate> templatesSupplier) {
		super(JsonTypes.ARRAY, name);
		if (minLen != -1 && minLen < 0)
			throw new IllegalArgumentException("Unacceptable minimum array length "+minLen);
		if (maxLen != -1 && ((minLen != -1 && maxLen < minLen) || maxLen < 0))
			throw new IllegalArgumentException("Unacceptable maximum array length "+maxLen);
		this.minLen = minLen;
		this.maxLen = maxLen;
		this.templatesSupplier = templatesSupplier == null ? (i)->null : templatesSupplier;
	}
	
	/**
	 * Utility static method to create a new instance with a single template for all elements of the array.
	 * <br>
	 * The returned instance is the equal to the one produced by
	 * {@link #JsonArrayTemplate(String, int, int, Function) new JsonArrayTemplate(name, minLen, maxLen, elementsTemplate == null ? null : (i)->elementsTemplate)}.
	 * 
	 * @param name This template's name, if {@code null} a default one will be used. The name is mainly
	 * 		used for identification.
	 * @param minLen The minimum (inclusive) length that the array shall have. Must be positive or {@code 0}.
	 * 		Set to {@code -1} to disable this check. If not set implicitely defaults to {@code 0}.
	 * @param maxLen The maximum (inclusive) length that the array shall have. Must be positive or {@code 0},
	 * 		and greater or equal to the minimum length if the said is different from {@code -1}.
	 * 		Set to {@code -1} to disable this check. If not set implicitely defaults to {@link Integer#MAX_VALUE}.
	 * @param elementsTemplate The template to be used for all the elements of the array, if {@code null} then
	 * 		no check of such kind will be executed.
	 * 
	 * @return A new instance as specified.
	 */
	public static JsonArrayTemplate withOmogeneusTemplate(String name, int minLen, int maxLen,
			JsonElementTemplate elementsTemplate) {
		return new JsonArrayTemplate(name, minLen, maxLen, elementsTemplate == null ? null : (i)->elementsTemplate);
	}
	
	@Override
	protected void verify(JsonArray array) throws JsonTemplateValidationException {
		int len = array.size();
		if (this.minLen != -1 && len < this.minLen)
			throw this.checker.getExceptionFactory()
				.apply("The JsonArray is shorter than the minimum allowed length "+this.minLen);
		if (this.maxLen != -1 && len > this.maxLen)
			throw this.checker.getExceptionFactory()
				.apply("The JsonArray is longer than the maximum allowed length "+this.maxLen);
		for (int i=0;i<len;i++) {
			JsonElementTemplate template = this.templatesSupplier.apply(i);
			if (template != null) template.validate(array.get(i), getCurrentTrace(), toString()+"["+i+"]");
		}
	}

}
