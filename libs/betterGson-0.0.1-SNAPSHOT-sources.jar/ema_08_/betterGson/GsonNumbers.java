package ema_08_.betterGson;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.util.Objects;
import java.util.function.Predicate;

import com.google.gson.*;

/**
 * An enumerator holding all the types a {@link JsonTypes#NUMBER JsonNumber} can
 * be represented in java, along with a wide variety of static check methods.
 */
public enum GsonNumbers {
	
	/**
	 * The most precise and wide in size representation of any number
	 * in java, implemented by {@link BigDecimal} class.
	 * <br>
	 * Any number stored in a {@link JsonPrimitive} may be represented by this type.
	 */
	BIG_DECIMAL(BigDecimal.class, null, GsonNumbers::canFitInBigDecimal),
	
	/**
	 * The most wide in size representation of any integer number in java,
	 * implemented by {@link BigInteger} class.
	 * <br>
	 * Any integer number stored in a {@link JsonPrimitive} may be represented by this type.
	 */
	BIG_INTEGER(BigInteger.class, null, GsonNumbers::canFitInBigInteger),
	
	/**
	 * Primitive java type that represents a 64 bit integer number, wrapped
	 * by {@link Long} class.
	 */
	LONG(Long.class, long.class, GsonNumbers::canFitInLong),
	
	/**
	 * Primitive java type that represents a 32 bit integer number, wrapped
	 * by {@link Integer} class.
	 */
	INTEGER(Integer.class, int.class, GsonNumbers::canFitInInteger),
	
	/**
	 * Primitive java type that represents a 16 bit integer number, wrapped
	 * by {@link Short} class.
	 */
	SHORT(Short.class, short.class, GsonNumbers::canFitInShort),
	
	/**
	 * Primitive java type that represents a 8 bit integer number (i.e. a single byte), wrapped
	 * by {@link Byte} class.
	 */
	BYTE(Byte.class, byte.class, GsonNumbers::canFitInByte),
	
	/**
	 * Primitive java type that represents a 64 bit floating point number, with a decimal precision
	 * of approximately 15 decimals. Wrapped by {@link Double} class.
	 */
	DOUBLE(Double.class, double.class, (pr)->GsonNumbers.canFitInDouble(pr, true)),
	
	/**
	 * Primitive java type that represents a 32 bit floating point number, with a decimal precision
	 * of approximately 6 decimals. Wrapped by {@link Float} class.
	 */
	FLOAT(Float.class, float.class, (pr)->GsonNumbers.canFitInFloat(pr, true));
	
	private final Class<? extends Number> javaClass;
	private final Class<?> primitiveClass;
	private final Predicate<JsonPrimitive> tester;
	
	GsonNumbers(Class<? extends Number> javaClass, Class<?> primitiveClass,
			Predicate<JsonPrimitive> tester) {
		this.javaClass = javaClass;
		this.primitiveClass = primitiveClass;
		this.tester = tester;
	}
	
	/**
	 * Retrieves this number representation's java class. If the number representation
	 * compiles to a primitive type then the wrapper class type is returned.
	 * 
	 * @return The class of the type of this number representation, never {@code null}.
	 */
	public Class<? extends Number> getJavaClass() {
		return this.javaClass;
	}
	
	/**
	 * Retrieves this number representation's primitive class. If the number representation
	 * does not compile to a primitive then returns null.
	 * 
	 * @return The primitive class of this number representation, if not a primitive returns {@code null}.
	 */
	public Class<?> getPrimitiveClass() {
		return this.primitiveClass;
	}
	
	/**
	 * Checks if the given {@link JsonPrimitive}, assumed to be a number as per
	 * {@link  JsonPrimitive#isNumber() isNumber()} method, can fit in this number
	 * representation without any loss or truncation.
	 * 
	 * @param primitive The primitive representing the number, must not be {@code null}.
	 * 
	 * @return {@code true} if the number can fit without loss, {@code false} otherwise.
	 */
	public boolean canFit(JsonPrimitive primitive) {
		return this.tester.test(primitive);
	}
	
	private static final BigInteger
		LONG_MAX_VALUE = BigInteger.valueOf(Long.MAX_VALUE),
		LONG_MIN_VALUE = BigInteger.valueOf(Long.MIN_VALUE),
		INT_MAX_VALUE = BigInteger.valueOf(Integer.MAX_VALUE),
		INT_MIN_VALUE = BigInteger.valueOf(Integer.MIN_VALUE),
		SHORT_MAX_VALUE = BigInteger.valueOf(Short.MAX_VALUE),
		SHORT_MIN_VALUE = BigInteger.valueOf(Short.MIN_VALUE),
		BYTE_MAX_VALUE = BigInteger.valueOf(Byte.MAX_VALUE),
		BYTE_MIN_VALUE = BigInteger.valueOf(Byte.MIN_VALUE);
	
	private static final BigDecimal
		DOUBLE_MAX_VALUE = BigDecimal.valueOf(Double.MAX_VALUE),
		DOUBLE_MIN_VALUE = BigDecimal.valueOf(-Double.MAX_VALUE),
		FLOAT_MAX_VALUE = BigDecimal.valueOf(Float.MAX_VALUE),
		FLOAT_MIN_VALUE = BigDecimal.valueOf(-Float.MAX_VALUE);
	
	private static final int
		DOUBLE_SAFE_DECIMALS = 15,
		FLOAT_SAFE_DECIMALS = 6;
	
	private static String jNum(JsonPrimitive primitive) {
		if (!Objects.requireNonNull(primitive, "Cannot operate on a null primitive").isNumber())
			throw new IllegalArgumentException("The given primitive does not represent a number");
		return primitive.getAsString();
	}
	
	private static boolean isInt(String sNum) {
		return new BigDecimal(sNum).stripTrailingZeros().scale() <= 0;
	}
	
	private static <T extends Number & Comparable<T>> boolean isWithin(T target,
			T minInclusive, T maxInclusive) {
		return target.compareTo(minInclusive) >= 0 &&
				target.compareTo(maxInclusive) <= 0;
	}
	
	private static boolean canIntegerFit(JsonPrimitive num, BigInteger max, BigInteger min) {
		String sNum = jNum(num);
		if (!isInt(sNum)) return false;
		return isWithin(new BigInteger(sNum), min, max);
	}
	
	private static BigDecimal trimToPrecision(BigDecimal original, int decimals) {
		original = original.stripTrailingZeros();
		if (original.scale() <= decimals) return original;
		return original.setScale(decimals, RoundingMode.HALF_UP)
                .stripTrailingZeros();
	}
	
	private static boolean isDecimalPrecise(BigDecimal num, int precision) {
		return num.stripTrailingZeros().scale() <= precision;
	}
	
	private static boolean canDecimalFit(BigDecimal num, BigDecimal max, BigDecimal min, int precision) {
		return isWithin(trimToPrecision(num, precision), min, max);
	}
	
	/**
	 * Checks if the given {@link JsonPrimitive}, assumed to be a number as per
	 * {@link  JsonPrimitive#isNumber() isNumber()} method, can fit in
	 * {@link BigInteger} without any loss or truncation.
	 * 
	 * @param num The primitive representing the number, must not be {@code null}.
	 * 
	 * @return {@code true} if the number can fit without loss, {@code false} otherwise.
	 */
	public static boolean canFitInBigInteger(JsonPrimitive num) {
		return isInt(jNum(num));
	}
	
	/**
	 * Checks if the given {@link JsonPrimitive}, assumed to be a number as per
	 * {@link  JsonPrimitive#isNumber() isNumber()} method, can fit in
	 * {@link Long} without any loss or truncation.
	 * 
	 * @param num The primitive representing the number, must not be {@code null}.
	 * 
	 * @return {@code true} if the number can fit without loss, {@code false} otherwise.
	 */
	public static boolean canFitInLong(JsonPrimitive num) {
		return canIntegerFit(num, LONG_MAX_VALUE, LONG_MIN_VALUE);
	}
	
	/**
	 * Checks if the given {@link JsonPrimitive}, assumed to be a number as per
	 * {@link  JsonPrimitive#isNumber() isNumber()} method, can fit in
	 * {@link Integer} without any loss or truncation.
	 * 
	 * @param num The primitive representing the number, must not be {@code null}.
	 * 
	 * @return {@code true} if the number can fit without loss, {@code false} otherwise.
	 */
	public static boolean canFitInInteger(JsonPrimitive num) {
		return canIntegerFit(num, INT_MAX_VALUE, INT_MIN_VALUE);
	}
	
	/**
	 * Checks if the given {@link JsonPrimitive}, assumed to be a number as per
	 * {@link  JsonPrimitive#isNumber() isNumber()} method, can fit in
	 * {@link Short} without any loss or truncation.
	 * 
	 * @param num The primitive representing the number, must not be {@code null}.
	 * 
	 * @return {@code true} if the number can fit without loss, {@code false} otherwise.
	 */
	public static boolean canFitInShort(JsonPrimitive num) {
		return canIntegerFit(num, SHORT_MAX_VALUE, SHORT_MIN_VALUE);
	}
	
	/**
	 * Checks if the given {@link JsonPrimitive}, assumed to be a number as per
	 * {@link  JsonPrimitive#isNumber() isNumber()} method, can fit in
	 * {@link Byte} without any loss or truncation.
	 * 
	 * @param num The primitive representing the number, must not be {@code null}.
	 * 
	 * @return {@code true} if the number can fit without loss, {@code false} otherwise.
	 */
	public static boolean canFitInByte(JsonPrimitive num) {
		return canIntegerFit(num, BYTE_MAX_VALUE, BYTE_MIN_VALUE);
	}
	
	/**
	 * Checks if the given {@link JsonPrimitive}, assumed to be a number as per
	 * {@link  JsonPrimitive#isNumber() isNumber()} method, can fit in
	 * {@link BigDecimal} without any loss or truncation.
	 * <br>
	 * Note that any valid number stored in json can always fit in {@link BigDecimal}.
	 * 
	 * @param num The primitive representing the number, must not be {@code null}.
	 * 
	 * @return {@code true} if the number can fit without loss, {@code false} otherwise.
	 */
	public static boolean canFitInBigDecimal(JsonPrimitive num) {
		jNum(num);
		return true;
	}
	
	/**
	 * Checks if the given {@link JsonPrimitive}, assumed to be a number as per
	 * {@link  JsonPrimitive#isNumber() isNumber()} method, can fit in
	 * {@link Double} without any loss or truncation.
	 * 
	 * @param num The primitive representing the number, must not be {@code null}.
	 * @param precisionWise If {@code true} the method will fail even if the number could fit by magnitude,
	 * 		but with precision loss, if {@code false} only magnitude is checked.
	 * 
	 * @return {@code true} if the number can fit without loss, {@code false} otherwise.
	 */
	public static boolean canFitInDouble(JsonPrimitive num, boolean precisionWise) {
		BigDecimal bNum = new BigDecimal(jNum(num));
		return canDecimalFit(bNum, DOUBLE_MAX_VALUE, DOUBLE_MIN_VALUE, DOUBLE_SAFE_DECIMALS) &&
				(!precisionWise || isDecimalPrecise(bNum, DOUBLE_SAFE_DECIMALS));
	}
	
	/**
	 * Checks if the given {@link JsonPrimitive}, assumed to be a number as per
	 * {@link  JsonPrimitive#isNumber() isNumber()} method, can fit in
	 * {@link Float} without any loss or truncation.
	 * 
	 * @param num The primitive representing the number, must not be {@code null}.
	 * @param precisionWise If {@code true} the method will fail even if the number could fit by magnitude,
	 * 		but with precision loss, if {@code false} only magnitude is checked.
	 * 
	 * @return {@code true} if the number can fit without loss, {@code false} otherwise.
	 */
	public static boolean canFitInFloat(JsonPrimitive num, boolean precisionWise) {
		BigDecimal bNum = new BigDecimal(jNum(num));
		return canDecimalFit(bNum, FLOAT_MAX_VALUE, FLOAT_MIN_VALUE, FLOAT_SAFE_DECIMALS) &&
				(!precisionWise || isDecimalPrecise(bNum, FLOAT_SAFE_DECIMALS));
	}
	
	/**
	 * Retrieves the given {@link JsonPrimitive}, assumed to be a number as per
	 * {@link  JsonPrimitive#isNumber() isNumber()} method, resolution (i.e. the number of decimals).
	 * 
	 * @param num The primitive representing the number, must not be {@code null}.
	 * 
	 * @return The number's resolution, {@code 0} for integers, never negative.
	 */
	public static int getResolution(JsonPrimitive num) {
		return Math.max(0,
				new BigDecimal(jNum(num)).stripTrailingZeros().scale());
	}

}
