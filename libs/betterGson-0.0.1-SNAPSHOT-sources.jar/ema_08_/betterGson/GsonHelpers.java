package ema_08_.betterGson;

import java.util.Objects;
import java.util.function.Function;
import java.util.function.Predicate;

import com.google.gson.*;

/**
 * A class that provides some static helper methods.
 */
public class GsonHelpers {
	
	private GsonHelpers() {}
	
	/**
	 * Safely runs the correct function for the given element's type.
	 * <br>
	 * Note that any {@link RuntimeException} thrown by the given functions will be passed to the
	 * caller.
	 * 
	 * @param <T> The functions return type.
	 * 
	 * @param element the element on which the function will be executed, may be {@code null}.
	 * @param onNullPointer Function that will run in case the given element is {@code null}, if {@code null}
	 * 		then no operation will be executed.
	 * @param onObject Function that will run in case the given element is a {@link JsonObject} as per
	 * 		{@link JsonElement#isJsonObject() isJsonObject()} method, if {@code null} then no operation will be executed.
	 * @param onArray Function that will run in case the given element is a {@link JsonArray} as per
	 * 		{@link JsonElement#isJsonArray() isJsonArray()} method, if {@code null} then no operation will be executed.
	 * @param onNull Function that will run in case the given element is a {@link JsonNull} as per
	 * 		{@link JsonElement#isJsonNull() isJsonNull()} method, if {@code null} then no operation will be executed.
	 * @param onPrimitive Function that will run in case the given element is a {@link JsonPrimitive} as per
	 * 		{@link JsonElement#isJsonPrimitive() isJsonPrimitive()} method, if {@code null} then no operation will be executed.
	 * 
	 * @return The return of the executed function, which may be {@code null}, or {@code null} if no function
	 * 		was specified for the element's type.
	 */
	public static <T> T runSafe(JsonElement element,
			Function<Void, T> onNullPointer, Function<JsonObject, T> onObject,
			Function<JsonArray, T> onArray, Function<JsonNull, T> onNull, Function<JsonPrimitive, T> onPrimitive) {
		if (element == null) return onNullPointer == null ? null : onNullPointer.apply(null);
		else if (element.isJsonObject()) return onObject == null ? null : onObject.apply(element.getAsJsonObject());
		else if (element.isJsonArray()) return onArray == null ? null : onArray.apply(element.getAsJsonArray());
		else if (element.isJsonNull()) return onNull == null ? null : onNull.apply(element.getAsJsonNull());
		else if (element.isJsonPrimitive()) return onPrimitive == null ? null : onPrimitive.apply(element.getAsJsonPrimitive());
		else throw new IllegalStateException("The given element is none of the expected types");
	}
	
	/**
	 * Checks the given element against a predicate, throwing in case the result is {@code false}.
	 * <br>
	 * Note that any {@link RuntimeException} thrown by the given functions will be passed to the
	 * caller.
	 * 
	 * @param <T> The element's effective class, if known.
	 * @param <E> The exception type thrown by this method.
	 * 
	 * @param element The element to check, may be {@code null}.
	 * @param checker The predicate that will grant the element's correctness, must not be {@code null}.
	 * @param exception A function that works as supplier, returning a never {@code null} exception of the
	 * 		declared type given as parameter the error message, if {@code null}
	 * 		{@link JsonParseException#JsonParseException(String) JsonParseException::new(String)} will be used instead.
	 * 		This function can assume that the given message is never {@code null}.
	 * @param message The exception message, if {@code null} a default one will be used instead.
	 * 
	 * @throws E If the check fails.
	 */
	public static <T extends JsonElement, E extends Exception> void check(T element, Predicate<T> checker,
			Function<String, E> exception, String message) throws E {
		Objects.requireNonNull(checker, "The checker predicate cannot be null");
		if (!checker.test(element)) {
			String msg = message == null ? "Unexpected JsonElement" : message;
			if (exception != null) {
				throw exception.apply(msg);
			} else {
				throw new JsonParseException(msg);
			}
		}
	}
	
	/**
	 * Validates the given element with a function, throwing in case the function's result is not {@code null}.
	 * <br>
	 * Note that any {@link RuntimeException} thrown by the given functions will be passed to the
	 * caller.
	 * 
	 * @param <T> The element's effective class, if known.
	 * @param <E> The exception type thrown by this method.
	 * 
	 * @param element The element to check, may be {@code null}.
	 * @param checker The function that will accept the element and will return an error message, or
	 * 		{@code null} if no error shall be thrown.
	 * @param exception A function that works as supplier, returning a never {@code null} exception of the
	 * 		declared type given as parameter the error message, if {@code null}
	 * 		{@link JsonParseException#JsonParseException(String) JsonParseException::new(String)} will be used instead.
	 * 		This function can assume that the given message is never {@code null}.
	 * 
	 * @throws E if the check fails.
	 */
	public static <T extends JsonElement, E extends Exception> void check(T element, Function<T, String> checker,
			Function<String, E> exception) throws E {
		Objects.requireNonNull(checker, "The checker predicate cannot be null");
		String res = checker.apply(element);
		if (res != null) {
			if (exception != null) {
				throw exception.apply(res);
			} else {
				throw new JsonParseException(res);
			}
		}
	}

}
