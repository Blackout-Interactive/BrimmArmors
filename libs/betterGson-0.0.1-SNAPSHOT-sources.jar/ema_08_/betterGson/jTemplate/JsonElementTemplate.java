package ema_08_.betterGson.jTemplate;

import java.util.ArrayList;
import java.util.Objects;
import java.util.function.Function;

import com.google.gson.*;

import ema_08_.betterGson.GsonChecker;
import ema_08_.betterGson.GsonHelpers;
import ema_08_.betterGson.JsonTypes;
import ema_08_.betterGson.exceptions.JsonTemplateValidationException;

/**
 * A template for a {@link JsonElement} that defined how the element should be,
 * by default defining only its {@link JsonsTypes}.
 * <br>
 * Elements can then be checked against this template to verify they are correctly
 * structured.
 * <br>
 * Unlike gson with its {@link JsonElement} hierarchy, the developer is encouraged,
 * especially in more complex system, to subclass this class in order to fulfil
 * their system's needs.
 */
public class JsonElementTemplate {
	
	/**
	 * The {@link JsonTypes type} of this element's template.
	 */
	protected final JsonTypes type;
	
	/**
	 * The {@link GsonChecker checker} to be used in this template.
	 */
	protected final GsonChecker<JsonTemplateValidationException> checker =
			new GsonChecker<>(
					JsonTemplateValidationException::new,
					this::getCurrentTrace
					);
	
	/**
	 * This template's name, as defined in construction.
	 */
	public final String name;
		
	private final Function<JsonObject, JsonTemplateValidationException>
		safeVerObject = (obj)->{
			try { verify(obj); return null; }
			catch (JsonTemplateValidationException e) { return e; }
		};
		
	private final Function<JsonArray, JsonTemplateValidationException>
		safeVerArray = (arr)->{
			try { verify(arr); return null; }
			catch (JsonTemplateValidationException e) { return e; }
		};
		
	private final Function<JsonNull, JsonTemplateValidationException>
		safeVerNull = (nul)->{
			try { verify(nul); return null; }
			catch (JsonTemplateValidationException e) { return e; }
		};
		
	private final Function<JsonPrimitive, JsonTemplateValidationException>
		safeVerPrimitive = (pri)->{
			try { verify(pri); return null; }
			catch (JsonTemplateValidationException e) { return e; }
		};
		
	private JsonElementsStacktTrace currentTrace;
	
	/**
	 * Constructs a new template that will require any checked element to be of the specified type.
	 * 
	 * @param type The expected element's type, cannot be {@code null}.
	 * @param name This template's name, if {@code null} a default one will be used. The name is mainly
	 * 		used for identification.
	 */
	public JsonElementTemplate(JsonTypes type, String name) {
		this.type = Objects.requireNonNull(type, "An element template must have a type");
		this.name = name == null ? "UnnamedTemplate" : name;
	}
	
	/**
	 * Utility static method to create a new instance for a {@link JsonTypes#BOOLEAN JsonBoolean} template with
	 * no further checks other than the type check.
	 * <br>
	 * The returned instance is the equal to the one produced by
	 * {@link #JsonElementTemplate(JsonTypes, String) new JsonElementTemplate(JsonTypes.BOOLEAN, name)}.
	 * 
	 * @param name This template's name, if {@code null} a default one will be used. The name is mainly
	 * 		used for identification.
	 * 
	 * @return a new instance as specified.
	 */
	public static JsonElementTemplate ofBoolean(String name) {
		return new JsonElementTemplate(JsonTypes.BOOLEAN, name);
	}
	
	/**
	 * Utility static method to create a new instance for a {@link JsonTypes#NULL JsonNull} template with no further
	 * checks other than the type check.
	 * <br>
	 * The returned instance is the equal to the one produced by
	 * {@link #JsonElementTemplate(JsonTypes, String) new JsonElementTemplate(JsonTypes.NULL, name)}.
	 * 
	 * @param name This template's name, if {@code null} a default one will be used. The name is mainly
	 * 		used for identification.
	 * 
	 * @return a new instance as specified.
	 */
	public static JsonElementTemplate ofNull(String name) {
		return new JsonElementTemplate(JsonTypes.NULL, name);
	}
	
	/**
	 * Validates the given element to be conform to this template.
	 * 
	 * @param element The element to validate, may be {@code null}.
	 * 
	 * @throws JsonTemplateValidationException In case the validation fails. The exception usually has a more detailed error message,
	 * 		although is not enforced (default exceptions always provide one).
	 */
	public final void validate(JsonElement element) throws JsonTemplateValidationException {
		if (this.currentTrace != null) throw new IllegalStateException("Already validating");
		validate(element, new JsonElementsStacktTrace(), null);
	}
	
	/**
	 * Validates the given element as sub element of the current validation.
	 * <br>
	 * Note that this method shall be invoked only within the following
	 * methods scopes:
	 * <ul>
	 * 		<li>{@link #verify(JsonObject)}</li>
	 * 		<li>{@link #verify(JsonArray)}</li>
	 * 		<li>{@link #verify(JsonNull)}</li>
	 * 		<li>{@link #verify(JsonPrimitive)}</li>
	 * </ul>
	 * 
	 * @param element The element to validate, may be {@code null}.
	 * @param trace The validation trace, which shall always be the result of
	 * 		{@link #getCurrentTrace()}, and never {@code null}.
	 * @param traceElementOverride An understandable name that express what is being pushed during this check,
	 * 		e.g. when checking an array in an extension of this class, it could be {@code this.name+[i]}.
	 * 		If {@code null} then {{@link #toString()} of {@code this} template will be used.
	 * 
	 * @throws JsonTemplateValidationException In case the validation fails. The exception usually has a more detailed error message,
	 * 		although is not enforced (default exceptions always provide one).
	 */
	protected final void validate(JsonElement element, JsonElementsStacktTrace trace, String traceElementOverride)
			throws JsonTemplateValidationException {
		this.currentTrace = Objects.requireNonNull(trace);
		this.currentTrace.push(traceElementOverride == null ? toString() : traceElementOverride);
		this.checker.assertJson(element, this.type);
		JsonTemplateValidationException exception = GsonHelpers.runSafe(element, null,
				this.safeVerObject,
				this.safeVerArray,
				this.safeVerNull,
				this.safeVerPrimitive);
		this.currentTrace.pop();
		this.currentTrace = null;
		if (exception != null) throw exception;
	}
	
	/**
	 * Retrieves this check's current trace, which is to be passed to any
	 * {@link #validate(JsonElement, JsonElementsStacktTrace) validation} of other
	 * templates during the validation of this template (e.g. sub elements).
	 * <br>
	 * Note that this method shall be invoked only within the following
	 * methods scopes:
	 * <ul>
	 * 		<li>{@link #verify(JsonObject)}</li>
	 * 		<li>{@link #verify(JsonArray)}</li>
	 * 		<li>{@link #verify(JsonNull)}</li>
	 * 		<li>{@link #verify(JsonPrimitive)}</li>
	 * </ul>
	 * 
	 * @return the current trace, never {@code null}
	 */
	protected JsonElementsStacktTrace getCurrentTrace() {
		if (this.currentTrace == null)
			throw new IllegalStateException("No trace is currently being monitored");
		return this.currentTrace;
	}
	
	/**
	 * Internal method that is called in {@link #validate(JsonElement) validate()}
	 * in case this template's type is {@link JsonTypes#OBJECT JsonObject} and the
	 * element passed type validation.
	 * <br>
	 * By default this is a no-op method.
	 * 
	 * @param jObject The {@link JsonObject} to verify, never {@code null}.
	 * 
	 * @throws JsonTemplateValidationException If the validation process should fail. The implementers are encouraged
	 * 		to always provide some context in the exception message when throwing.
	 */
	protected void verify(JsonObject jObject) throws JsonTemplateValidationException {}
	
	/**
	 * Internal method that is called in {@link #validate(JsonElement) validate()}
	 * in case this template's type is {@link JsonTypes#ARRAY JsonArray} and the
	 * element passed type validation.
	 * <br>
	 * By default this is a no-op method.
	 * 
	 * @param jArray The {@link JsonArray} to verify, never {@code null}.
	 * 
	 * @throws JsonTemplateValidationException If the validation process should fail. The implementers are encouraged
	 * 		to always provide some context in the exception message when throwing.
	 */
	protected void verify(JsonArray jArray) throws JsonTemplateValidationException {}
	
	/**
	 * Internal method that is called in {@link #validate(JsonElement) validate()}
	 * in case this template's type is {@link JsonTypes#NULL JsonNull} and the
	 * element passed type validation.
	 * <br>
	 * By default this is a no-op method.
	 * 
	 * @param jNull The {@link JsonNull} to verify, never {@code null}.
	 * 
	 * @throws JsonTemplateValidationException If the validation process should fail. The implementers are encouraged
	 * 		to always provide some context in the exception message when throwing.
	 */
	protected void verify(JsonNull jNull) throws JsonTemplateValidationException {}
	
	/**
	 * Internal method that is called in {@link #validate(JsonElement) validate()}
	 * in case this template's type is {@link JsonTypes#NUMBER JsonNumber},
	 * {@link JsonTypes#BOOLEAN JsonBoolean} or {@link JsonTypes#STRING JsonString} and the
	 * element passed type validation.
	 * <br>
	 * Note that despite the lack of class-level division of these 3 json types in gson,
	 * the passed {@link JsonPrimitive} is granted to comply with this template's exact type.
	 * <br>
	 * By default this is a no-op method.
	 * 
	 * @param jPrimitive The {@link JsonPrimitive} to verify, never {@code null}.
	 * 
	 * @throws JsonTemplateValidationException If the validation process should fail. The implementers are encouraged
	 * 		to always provide some context in the exception message when throwing.
	 */
	protected void verify(JsonPrimitive jPrimitive) throws JsonTemplateValidationException {}
	
	@Override
	public String toString() {
		return this.type+":"+this.name;
	}
	
	/**
	 * Class representing the validation stack for nested validations,
	 * it is handled automatically and class that extends {@link JsonElementTemplate}
	 * only need to pass it during
	 * {@link JsonElementTemplate#validate(JsonElement, JsonElementsStacktTrace) nested validations}.
	 */
	public static final class JsonElementsStacktTrace {
			
		private final ArrayList<String> trace = new ArrayList<>();
		
		private JsonElementsStacktTrace() {}
		
		private void push(String traceElement) {
			this.trace.add(Objects.requireNonNull(traceElement, "Cannot push null traceElement"));
		}
		
		private void pop() {
			this.trace.remove(this.trace.size()-1);
		}
		
		/**
		 * Retrieve this instance's call trace, ordered from oldest to latest template verified.
		 * <br>
		 * Mainly used internally.
		 * 
		 * @return this instance's call trace.
		 */
		public String[] getTrace() {
			return this.trace.toArray(new String[0]);
		}
		
	}

}
