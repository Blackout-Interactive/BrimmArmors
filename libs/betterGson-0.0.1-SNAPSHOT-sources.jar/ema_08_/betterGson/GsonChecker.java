package ema_08_.betterGson;

import java.util.Objects;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

import com.google.gson.*;

/**
 * Helper class which provides methods to perform checks on json elements.
 * 
 * @param <E> The type of exception thrown by this checker.
 */
public class GsonChecker<E extends Exception> {
	
	private static final BiFunction<JsonElement, Class<? extends JsonElement>, Boolean>
		nullsafe_assertType = (el, clazz)->
			el != null && Objects.requireNonNull(clazz, "Cannot check against null class")
				.isAssignableFrom(el.getClass());
			
	private static final Predicate<JsonElement>
		nullsafe_assertJsonObject = (el)->el != null && el.isJsonObject(),
		nullsafe_assertJsonArray = (el)->el != null && el.isJsonArray(),
		nullsafe_assertJsonNull = (el)->el != null && el.isJsonNull(),
		nullsafe_assertJsonPrimitive = (el)->el != null && el.isJsonPrimitive();
		
	private static final Predicate<JsonPrimitive>
		nullsafe_assertJsonBoolean = (pr)->pr != null && pr.isBoolean(),
		nullsafe_assertJsonNumber = (pr)->pr != null && pr.isNumber(),
		nullsafe_assertJsonString = (pr)->pr != null && pr.isString(),
		
		assertJsonDoublePrecise = (pr)->GsonNumbers.canFitInDouble(pr, true),
		assertJsonDoubleBroad = (pr)->GsonNumbers.canFitInDouble(pr, false),
		assertJsonFloatPrecise = (pr)->GsonNumbers.canFitInFloat(pr, true),
		assertJsonFloatBroad = (pr)->GsonNumbers.canFitInFloat(pr, false);
		
		
	private static String getExactType(JsonPrimitive primitive) {
		return primitive.isBoolean() ? "JsonBoolean" :
				primitive.isNumber() ? "JsonNumber" :
				primitive.isString() ? "JsonString" :
					"UnknownPrimitiveType";
	}
	
	private final Function<String, E> exceptionFactory;
	
	/**
	 * Creates a new instance with the given exception factory.
	 * 
	 * @param <C> The context type that will be passed to the exception factory.
	 * 
	 * @param exceptionFactory A function that given the error message and the context provided by the context
	 * 		supplier, returns a never {@code null} exception of the declared type. This parameter cannot be {@code null}.
	 * @param contextProvider A supplier that provides a context of the declared type (possibly {@code null} to be
	 * 		passed to the exception factory. If {@code null} then all passed contexts will be {@code null}.
	 * 		The supplier is called at the moment of exception construction.
	 */
	public <C> GsonChecker(BiFunction<String, C, E> exceptionFactory, Supplier<C> contextProvider) {
		Objects.requireNonNull(exceptionFactory, "The exceptions factory cannot be null");
		final Supplier<C> cp = contextProvider == null ? ()->null : contextProvider;
		this.exceptionFactory = (msg)->exceptionFactory.apply(msg, cp.get());
	}
	
	/**
	 * Retrieve this checker's exception factory as it was passed in construction.
	 * <br>
	 * Mainly used internally.
	 * 
	 * @return The exception factory, never {@code null}.
	 */
	public Function<String, E> getExceptionFactory() {
		return this.exceptionFactory;
	}
	
	/**
	 * Asserts the given {@link JsonElement} to be a {@link JsonObject} via its
	 * {@link JsonElement#isJsonObject() own check implementation}, thus fully supporting custom subclasses.
	 * 
	 * @param element The element to check, may be {@code null}.
	 * 
	 * @return The return of the given element's {@link JsonElement#getAsJsonObject() getAsJsonObject()} method.
	 * 
	 * @throws E If the given element is {@code null} or its {@link JsonElement#isJsonObject() isJsonObject()}
	 * 		function returns {@code false}. The exception has a message providing a brief description of the cause
	 * 		and the actual type of the element (it's class' Simple name).
	 */
	public JsonObject assertJsonObject(JsonElement element) throws E {
		GsonHelpers.check(element,
				nullsafe_assertJsonObject,
				this.exceptionFactory,
				"Expected a JsonObject, but the element was "+(
						element == null ? "null" : "a "+element.getClass().getSimpleName()
								));
		return element.getAsJsonObject();
	}
	
	/**
	 * Asserts the given {@link JsonElement} to be a {@link JsonArray} via its
	 * {@link JsonElement#isJsonArray() own check implementation}, thus fully supporting custom subclasses.
	 * 
	 * @param element The element to check, may be {@code null}.
	 * 
	 * @return The return of the given element's {@link JsonElement#getAsJsonArray() getAsJsonArray()} method.
	 * 
	 * @throws E If the given element is {@code null} or its {@link JsonElement#isJsonArray() isJsonArray()}
	 * 		function returns {@code false}. The exception has a message providing a brief description of the cause
	 * 		and the actual type of the element (it's class' Simple name).
	 */
	public JsonArray assertJsonArray(JsonElement element) throws E {
		GsonHelpers.check(element,
				nullsafe_assertJsonArray,
				this.exceptionFactory,
				"Expected a JsonArray, but the element was "+(
						element == null ? "null" : "a "+element.getClass().getSimpleName()
								));
		return element.getAsJsonArray();
	}
	
	/**
	 * Asserts the given {@link JsonElement} to be a {@link JsonNull} via its
	 * {@link JsonElement#isJsonNull() own check implementation}, thus fully supporting custom subclasses.
	 * 
	 * @param element The element to check, may be {@code null}.
	 * 
	 * @return The return of the given element's {@link JsonElement#getAsJsonNull() getAsJsonNull()} method.
	 * 
	 * @throws E If the given element is {@code null} or its {@link JsonElement#isJsonNull() isJsonNull()}
	 * 		function returns {@code false}. The exception has a message providing a brief description of the cause
	 * 		and the actual type of the element (it's class' Simple name).
	 */
	public JsonNull assertJsonNull(JsonElement element) throws E {
		GsonHelpers.check(element,
				nullsafe_assertJsonNull,
				this.exceptionFactory,
				"Expected a JsonNull, but the element was "+(
						element == null ? "null" : "a "+element.getClass().getSimpleName()
								));
		return element.getAsJsonNull();
	}
	
	/**
	 * Asserts the given {@link JsonElement} to be a {@link JsonPrimitive} via its
	 * {@link JsonElement#isJsonPrimitive() own check implementation}, thus fully supporting custom subclasses.
	 * 
	 * @param element The element to check, may be {@code null}.
	 * 
	 * @return The return of the given element's {@link JsonElement#getAsJsonPrimitive() getAsJsonPrimitive()} method.
	 * 
	 * @throws E If the given element is {@code null} or its {@link JsonElement#isJsonPrimitive() isJsonPrimitive()}
	 * 		function returns {@code false}. The exception has a message providing a brief description of the cause
	 * 		and the actual type of the element (it's class' Simple name).
	 */
	public JsonPrimitive assertJsonPrimitive(JsonElement element) throws E {
		GsonHelpers.check(element,
				nullsafe_assertJsonPrimitive,
				this.exceptionFactory,
				"Expected a JsonPrimitive, but the element was "+(
						element == null ? "null" : "a "+element.getClass().getSimpleName()
								));
		return element.getAsJsonPrimitive();
	}
	
	/**
	 * Asserts the given {@link JsonPrimitive} to be a {@code JsonBoolean} via its
	 * {@link JsonPrimitive#isBoolean() own check implementation}, thus fully supporting custom subclasses.
	 * 
	 * @param primitive The primitive to check, may be {@code null}.
	 * 
	 * @return The given primitive.
	 * 
	 * @throws E If the given primitive is {@code null} or its {@link JsonPrimitive#isBoolean() isBoolean()}
	 * 		function returns {@code false}. The exception has a message providing a brief description of the cause
	 * 		and the actual type of the element.
	 */
	public JsonPrimitive assertJsonBoolean(JsonPrimitive primitive) throws E {
		GsonHelpers.check(primitive,
				nullsafe_assertJsonBoolean,
				this.exceptionFactory,
				"Expected a JsonBoolean, but the element was "+(
						primitive == null ? "null" : "a "+getExactType(primitive)
								));
		return primitive;
	}
	
	/**
	 * Asserts the given {@link JsonPrimitive} to be a {@code JsonNumber} via its
	 * {@link JsonPrimitive#isNumber() own check implementation}, thus fully supporting custom subclasses.
	 * 
	 * @param primitive The primitive to check, may be {@code null}.
	 * 
	 * @return The given primitive.
	 * 
	 * @throws E If the given primitive is {@code null} or its {@link JsonPrimitive#isNumber() isNumber()}
	 * 		function returns {@code false}. The exception has a message providing a brief description of the cause
	 * 		and the actual type of the element.
	 */
	public JsonPrimitive assertJsonNumber(JsonPrimitive primitive) throws E {
		GsonHelpers.check(primitive,
				nullsafe_assertJsonNumber,
				this.exceptionFactory,
				"Expected a JsonNumber, but the element was "+(
						primitive == null ? "null" : "a "+getExactType(primitive)
								));
		return primitive;
	}
	
	/**
	 * Asserts the given {@link JsonPrimitive} to be a {@code JsonString} via its
	 * {@link JsonPrimitive#isString() own check implementation}, thus fully supporting custom subclasses.
	 * 
	 * @param primitive The primitive to check, may be {@code null}.
	 * 
	 * @return The given primitive.
	 * 
	 * @throws E If the given primitive is {@code null} or its {@link JsonPrimitive#isString() isString()}
	 * 		function returns {@code false}. The exception has a message providing a brief description of the cause
	 * 		and the actual type of the element.
	 */
	public JsonPrimitive assertJsonString(JsonPrimitive primitive) throws E {
		GsonHelpers.check(primitive,
				nullsafe_assertJsonString,
				this.exceptionFactory,
				"Expected a JsonString, but the element was "+(
						primitive == null ? "null" : "a "+getExactType(primitive)
								));
		return primitive;
	}
	
	/**
	 * Asserts the given {@link JsonPrimitive} to be a {@code JsonNumber} compatible
	 * with {@link java.math.BigInteger BigInteger}.
	 * <br>
	 * This method relies on {@link #assertJsonNumber(JsonPrimitive) assertJsonNumber} to
	 * grant that the primitive is a number.
	 * 
	 * @param primitive The primitive to check, may be {@code null}.
	 * 
	 * @return The given primitive.
	 * 
	 * @throws E If {@link #assertJsonNumber(JsonPrimitive) assertJsonNumber} does,
	 * 		or the number is not integer. The exception has a message providing a brief description
	 * 		of the cause and the actual type of the element if needed.
	 */
	public JsonPrimitive assertJsonBigInteger(JsonPrimitive primitive) throws E {
		GsonHelpers.check(assertJsonNumber(primitive),
				GsonNumbers::canFitInBigInteger,
				this.exceptionFactory,
				"The provided JsonNumber cannot fit in BigInteger representation without loss");
		return primitive;
	}
	
	/**
	 * Asserts the given {@link JsonPrimitive} to be a {@code JsonNumber} compatible
	 * with {@link Long}.
	 * <br>
	 * This method relies on {@link #assertJsonNumber(JsonPrimitive) assertJsonNumber} to
	 * grant that the primitive is a number.
	 * 
	 * @param primitive The primitive to check, may be {@code null}.
	 * 
	 * @return The given primitive.
	 * 
	 * @throws E If {@link #assertJsonNumber(JsonPrimitive) assertJsonNumber} does,
	 * 		the number is not integer, or too big to fit in {@link Long}. The exception has
	 * 		a message providing a brief description of the cause and the actual type of the
	 *      element if needed.
	 */
	public JsonPrimitive assertJsonLong(JsonPrimitive primitive) throws E {
		GsonHelpers.check(assertJsonNumber(primitive),
				GsonNumbers::canFitInLong,
				this.exceptionFactory,
				"The provided JsonNumber cannot fit in Long representation without loss");
		return primitive;
	}
	
	/**
	 * Asserts the given {@link JsonPrimitive} to be a {@code JsonNumber} compatible
	 * with {@link Integer}.
	 * <br>
	 * This method relies on {@link #assertJsonNumber(JsonPrimitive) assertJsonNumber} to
	 * grant that the primitive is a number.
	 * 
	 * @param primitive The primitive to check, may be {@code null}.
	 * 
	 * @return The given primitive.
	 * 
	 * @throws E If {@link #assertJsonNumber(JsonPrimitive) assertJsonNumber} does,
	 * 		the number is not integer, or too big to fit in {@link Integer}. The exception has
	 * 		a message providing a brief description of the cause and the actual type of the
	 *      element if needed.
	 */
	public JsonPrimitive assertJsonInteger(JsonPrimitive primitive) throws E {
		GsonHelpers.check(assertJsonNumber(primitive),
				GsonNumbers::canFitInInteger,
				this.exceptionFactory,
				"The provided JsonNumber cannot fit in Integer representation without loss");
		return primitive;
	}
	
	/**
	 * Asserts the given {@link JsonPrimitive} to be a {@code JsonNumber} compatible
	 * with {@link Short}.
	 * <br>
	 * This method relies on {@link #assertJsonNumber(JsonPrimitive) assertJsonNumber} to
	 * grant that the primitive is a number.
	 * 
	 * @param primitive The primitive to check, may be {@code null}.
	 * 
	 * @return The given primitive.
	 * 
	 * @throws E If {@link #assertJsonNumber(JsonPrimitive) assertJsonNumber} does,
	 * 		the number is not integer, or too big to fit in {@link Short}. The exception has
	 * 		a message providing a brief description of the cause and the actual type of the
	 *      element if needed.
	 */
	public JsonPrimitive assertJsonShort(JsonPrimitive primitive) throws E {
		GsonHelpers.check(assertJsonNumber(primitive),
				GsonNumbers::canFitInShort,
				this.exceptionFactory,
				"The provided JsonNumber cannot fit in Short representation without loss");
		return primitive;
	}
	
	/**
	 * Asserts the given {@link JsonPrimitive} to be a {@code JsonNumber} compatible
	 * with {@link Byte}.
	 * <br>
	 * This method relies on {@link #assertJsonNumber(JsonPrimitive) assertJsonNumber} to
	 * grant that the primitive is a number.
	 * 
	 * @param primitive The primitive to check, may be {@code null}.
	 * 
	 * @return The given primitive.
	 * 
	 * @throws E If {@link #assertJsonNumber(JsonPrimitive) assertJsonNumber} does,
	 * 		the number is not integer, or too big to fit in {@link Byte}. The exception has
	 * 		a message providing a brief description of the cause and the actual type of the
	 *      element if needed.
	 */
	public JsonPrimitive assertJsonByte(JsonPrimitive primitive) throws E {
		GsonHelpers.check(assertJsonNumber(primitive),
				GsonNumbers::canFitInByte,
				this.exceptionFactory,
				"The provided JsonNumber cannot fit in Byte representation without loss");
		return primitive;
	}
	
	/**
	 * Asserts the given {@link JsonPrimitive} to be a {@code JsonNumber} compatible
	 * with {@link java.math.BigDecimal BigDecimal}.
	 * <br>
	 * This is only a formal wrapper for {@link #assertJsonNumber(JsonPrimitive) assertJsonNumber}
	 * method, since any number stored in json can be seen as {@link java.math.BigDecimal BigDecimal}.
	 * 
	 * @param primitive The primitive to check, may be {@code null}.
	 * 
	 * @return The given primitive.
	 * 
	 * @throws E If {@link #assertJsonNumber(JsonPrimitive) assertJsonNumber} does. The exception
	 * 		has a message providing a brief description of the cause and the actual type of the element if needed.
	 */
	public JsonPrimitive assertJsonBigDecimal(JsonPrimitive primitive) throws E {
		return assertJsonNumber(primitive);
	}
	
	/**
	 * Asserts the given {@link JsonPrimitive} to be a {@code JsonNumber} compatible
	 * with {@link Double}.
	 * <br>
	 * This method relies on {@link #assertJsonNumber(JsonPrimitive) assertJsonNumber} to
	 * grant that the primitive is a number.
	 * 
	 * @param primitive The primitive to check, may be {@code null}.
	 * @param precisionWise If {@code true} the assertion will fail if the number
	 * 		would loose floating point precision during the cast, if {@code false}
	 * 		such event won't trigger an exception.
	 * 
	 * @return The given primitive.
	 * 
	 * @throws E If {@link #assertJsonNumber(JsonPrimitive) assertJsonNumber} does,
	 * 		the number is too big to fit in {@link Double} or the call requires to guard against
	 * 		precision loss, and the number would loose floating point precision. The exception has
	 * 		a message providing a brief description of the cause and the actual type of the
	 *      element if needed.
	 */
	public JsonPrimitive assertJsonDouble(JsonPrimitive primitive, boolean precisionWise) throws E {
		GsonHelpers.check(assertJsonNumber(primitive),
				precisionWise ? assertJsonDoublePrecise : assertJsonDoubleBroad,
				this.exceptionFactory,
				"The provided JsonNumber cannot fit in Double representation without loss");
		return primitive;
	}
	
	/**
	 * Asserts the given {@link JsonPrimitive} to be a {@code JsonNumber} compatible
	 * with {@link Float}.
	 * <br>
	 * This method relies on {@link #assertJsonNumber(JsonPrimitive) assertJsonNumber} to
	 * grant that the primitive is a number.
	 * 
	 * @param primitive The primitive to check, may be {@code null}.
	 * @param precisionWise If {@code true} the assertion will fail if the number
	 * 		would loose floating point precision during the cast, if {@code false}
	 * 		such event won't trigger an exception.
	 * 
	 * @return The given primitive.
	 * 
	 * @throws E If {@link #assertJsonNumber(JsonPrimitive) assertJsonNumber} does,
	 * 		the number is too big to fit in {@link Float} or the call requires to guard against
	 * 		precision loss, and the number would loose floating point precision. The exception has
	 * 		a message providing a brief description of the cause and the actual type of the
	 *      element if needed.
	 */
	public JsonPrimitive assertJsonFloat(JsonPrimitive primitive, boolean precisionWise) throws E {
		GsonHelpers.check(assertJsonNumber(primitive),
				precisionWise ? assertJsonFloatPrecise : assertJsonFloatBroad,
				this.exceptionFactory,
				"The provided JsonNumber cannot fit in Float representation without loss");
		return primitive;
	}
	
	/**
	 * @deprecated
	 * This method may produce unreliable results with non standard implementations of {@link JsonElement},
	 * thus the user shall rely when possible on {@link #assertJson(JsonElement, JsonTypes) assertJson} for
	 * programmatic checks of an arbitrary type.
	 * <br><br>
	 * Asserts the given {@link JsonElement} to be of a specific sub type.
	 * <br>
	 * Note that this method is only granted to work properly when working with standard {@code gson} library classes,
	 * but it may fail when operating with custom extensions of {@link JsonElement} class, especially if they override
	 * the default methods to check if an element is an {@link JsonElement#isJsonObject() JsonObject},
	 * a {@link JsonElement#isJsonArray() JsonArray}, a {@link JsonElement#isJsonNull() JsonNull}, or a
	 * {@link JsonElement#isJsonPrimitive() JsonPrimitive}.
	 * <br>
	 * Two special cases are defined as follows:
	 * <ul>
	 *   <li>If the given class reference is {@link JsonElement JsonElement.class} then an exception will never be thrown.</li>
	 *   <li>If the given element is {@code null} an exception will be thrown in any case, including if the previously
	 *   		mentioned special case occurs.</li>
	 * </ul>
	 * 
	 * @param element The element to check, may be {@code null}.
	 * @param ref The reference class, cannot be {@code null}.
	 * 
	 * @throws E If the given element is {@code null} or is not a subclass as expressed by the given reference class.
	 * 		The exception has a message providing a brief description of the cause and the actual type of the
	 * 		element (it's class' Simple name), with the expected type in the same format.
	 */
	public void assertJsonElementImpl(JsonElement element, Class<? extends JsonElement> ref) throws E {
		GsonHelpers.check(element,
				(el)->nullsafe_assertType.apply(el, ref),
				this.exceptionFactory,
				"Expected a "+ref.getSimpleName()+", but the element was "+(
						element == null ? "null" : "a "+element.getClass().getSimpleName()
								));
	}
	
	/**
	 * Asserts the given {@link JsonElement} to be of the specified {@link JsonTypes type}.
	 * 
	 * @param element The element to check, may be {@code null}.
	 * @param type The expected element type, must not be {@code null}.
	 * 
	 * @throws E if the assertion fails as per the documentation of the assertion method of this class
	 * 		corresponding to the expected type.
	 */
	public void assertJson(JsonElement element, JsonTypes type) throws E {
		Objects.requireNonNull(type, "Cannot assert against null type");
		switch (type) {
		case OBJECT: assertJsonObject(element); break;
		case ARRAY: assertJsonArray(element); break;
		case NULL: assertJsonNull(element); break;
		case STRING: assertJsonString(assertJsonPrimitive(element)); break;
		case BOOLEAN: assertJsonBoolean(assertJsonPrimitive(element)); break;
		case NUMBER: assertJsonNumber(assertJsonPrimitive(element)); break;
		default: throw new IllegalArgumentException("Unsupported type enumerator value "+type);
		}
	}
	
	/**
	 * Asserts the given {@link JsonPrimitive} to be of the specified {@link GsonNumbers type}.
	 * 
	 * @param primitive The primitive to check, may be {@code null}.
	 * @param type The expected element type, must not be {@code null}.
	 * 
	 * @throws E if the assertion fails as per the documentation of the assertion method of this class
	 * 		corresponding to the expected type.
	 */
	public void assertJsonNumber(JsonPrimitive primitive, GsonNumbers type) throws E {
		Objects.requireNonNull(type, "Cannot assert against null type");
		switch (type) {
		case BIG_DECIMAL: assertJsonBigDecimal(primitive); break;
		case BIG_INTEGER: assertJsonBigInteger(primitive); break;
		case LONG: assertJsonLong(primitive); break;
		case INTEGER: assertJsonInteger(primitive); break;
		case SHORT: assertJsonShort(primitive); break;
		case BYTE: assertJsonByte(primitive); break;
		case DOUBLE: assertJsonDouble(primitive, true); break;
		case FLOAT: assertJsonFloat(primitive, true); break;
		default: throw new IllegalArgumentException("Unsupported type enumerator value "+type);
		}
	}
	
}
