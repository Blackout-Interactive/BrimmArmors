package ema_08_.betterGson.exceptions;

import ema_08_.betterGson.jTemplate.JsonElementTemplate;

/**
 * Exception type used throughout {@link JsonElementTemplate} and subclasses to signal a malformed
 * element when verifying a template.
 */
public class JsonTemplateValidationException extends Exception {

	private static final long serialVersionUID = 2421903953559079990L;
	
	private final String[] trace;
	
	/**
	 * Instantiates a new exception with the given parameters.
	 * 
	 * @param message The error message, if {@code null} a default one will be used.
	 * @param trace The {@link JsonElementTemplate.JsonElementsStacktTrace} that infers the context
	 * 		of this exception, may be {@ode null} if unknown.
	 */
	public JsonTemplateValidationException(String message, JsonElementTemplate.JsonElementsStacktTrace trace) {
		super(message == null ? "Unknown validation error" : message);
		this.trace = trace == null ? new String[] {"unknown_source"} : trace.getTrace();
	}
	
	/**
	 * Retrieves this exception's trace as a readable, single line string.
	 * 
	 * @return the trace, never {@code null}.
	 */
	public String getTrace() {
		return String.join(" > ", this.trace);
	}
	
	/**
	 * Retrieves this exception's trace as a readable string with possibly more than on line,
	 * similar to the output of {@link #printStackTrace()} on terminal.
	 * 
	 * @return the trace, never {@code null}.
	 */
	public String prettyPrint() {
		return this.getMessage()+"\n	"+
				String.join("\n		in ", this.trace);
	}

}
