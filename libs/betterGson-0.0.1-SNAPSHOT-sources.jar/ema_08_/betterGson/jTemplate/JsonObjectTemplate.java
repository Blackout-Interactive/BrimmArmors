package ema_08_.betterGson.jTemplate;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.google.gson.*;

import ema_08_.betterGson.JsonTypes;
import ema_08_.betterGson.exceptions.JsonTemplateValidationException;

/**
 * Default implementation of {@link JsonElementTemplate} for {@link JsonTypes#OBJECT JsonObject}s.
 */
public final class JsonObjectTemplate extends JsonElementTemplate {
	
	private final Map<String, JsonElementTemplate> requiredTemplates;
	private final Function<String, JsonElementTemplate> extrasVerifier;

	public JsonObjectTemplate(String name, Map<String, JsonElementTemplate> requiredTemplates,
			Function<String, JsonElementTemplate> extrasVerifier) {
		super(JsonTypes.OBJECT, name);
		this.requiredTemplates = requiredTemplates == null ?
				new HashMap<>() : Collections.unmodifiableMap(requiredTemplates);
		this.extrasVerifier = extrasVerifier == null ?
				(s)->null : extrasVerifier;
	}
	
	@Override
	protected void verify(JsonObject object) throws JsonTemplateValidationException {
		Set<Map.Entry<String, JsonElement>> objEntrySet = new HashSet<>(object.entrySet());
		for (Entry<String, JsonElementTemplate> entry : this.requiredTemplates.entrySet()) {
			JsonElementTemplate templ = Objects.requireNonNull(entry.getValue());
			String key = entry.getKey();
			JsonElement value = object.get(key);
			templ.validate(value, getCurrentTrace(), toString()+"["+key+"]");
		}
		objEntrySet = 
				objEntrySet.stream()
				.filter((entry)->this.requiredTemplates.get(entry.getKey()) == null)
				.collect(Collectors.toSet());
		for (Entry<String, JsonElement> entry : objEntrySet) {
			JsonElementTemplate template = this.extrasVerifier.apply(entry.getKey());
			if (template != null)
				template.validate(entry.getValue(), getCurrentTrace(), toString()+"["+entry.getKey()+"]");
		}
	}

}
