package ema_08_.betterGson;

import com.google.gson.*;

/**
 * An enumerator holding the 6 official Json types.
 * <br>
 * This enumerator does not have an inertly specific use.
 */
public enum JsonTypes {
	
	/**
	 * {@code JsonObject} type, represented in Gson via {@link JsonObject} class.
	 */
	OBJECT,
	
	/**
	 * {@code JsonArray} type, represented in Gson via {@link JsonArray} class.
	 */
	ARRAY,
	
	/**
	 * {@code JsonNumber} type, represented in Gson via {@link JsonPrimitive} whenever
	 * {@link JsonPrimitive#isNumber() isNumber()} function of then instance returns {@code true}.
	 */
	NUMBER,
	
	/**
	 * {@code JsonString} type, represented in Gson via {@link JsonPrimitive} whenever
	 * {@link JsonPrimitive#isString() isString()} function of then instance returns {@code true}.
	 */
	STRING,
	
	/**
	 * {@code JsonBoolean} type, represented in Gson via {@link JsonPrimitive} whenever
	 * {@link JsonPrimitive#isBoolean() isBoolean()} function of then instance returns {@code true}.
	 */
	BOOLEAN,
	
	/**
	 * {@code JsonArray} type, represented in Gson via {@link JsonNull} class.
	 */
	NULL;
	
	@Override
	public String toString() {
		switch(this) {
		case OBJECT: return "JsonObject";
		case ARRAY: return "JsonArray";
		case NUMBER: return "JsonNumber";
		case STRING: return "JsonString";
		case BOOLEAN: return "JsonBoolean";
		case NULL: return "JsonNull";
		default: throw new IllegalStateException("Unkown constant type: "+this.name());
		}
	}

}
