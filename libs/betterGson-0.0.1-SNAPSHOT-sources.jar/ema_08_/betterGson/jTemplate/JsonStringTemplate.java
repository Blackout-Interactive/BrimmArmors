package ema_08_.betterGson.jTemplate;

import java.util.Objects;

import com.google.gson.*;

import ema_08_.betterGson.JsonTypes;
import ema_08_.betterGson.exceptions.JsonTemplateValidationException;

/**
 * Default implementation of {@link JsonElementTemplate} for {@link JsonTypes#STRING JsonString}s.
 */
public final class JsonStringTemplate extends JsonElementTemplate {
	
	private final String prefix, suffix;
	private final String[] contains, matches;
	private final boolean containsAll, matchesAll;

	/**
	 * Constructs a new template with the type {@link JsonTypes#STRING JsonString} and the given parameters.
	 * 
	 * @param name This template's name, if {@code null} a default one will be used. The name is mainly
	 * 		used for identification.
	 * @param prefix The expected prefix to check, if {@code null} no prefix check will be applied.
	 * @param suffix The expected suffix to check, if {@code null} no suffix check will be applied.
	 * @param contains An array of strings that will be applied to the
	 * 		{@link String#contains(CharSequence) contains} method of the JsonString checked, if {@code null}
	 * 		or empty then no check will be applied. No elements are allowed to be {@code null}.
	 * @param containsAll If {@code true} the check will succeed only if all elements of contains array
	 * 		are effectively contained in the JsonString, if {@code false} the check will succeed if any of
	 * 		the said elements are effectively contained in the JsonString. If no contains check is applied
	 * 		then this option is ignored.
	 * @param matches An array of strings that will be applied to the
	 * 		{@link String#matches(CharSequence) matches} method of the JsonString checked, if {@code null}
	 * 		or empty then no check will be applied. No elements are allowed to be {@code null}.
	 * @param matchesAll If {@code true} the check will succeed only if all elements of matches array
	 * 		are effectively matched by the JsonString, if {@code false} the check will succeed if any of
	 * 		the said elements are effectively matched by the JsonString. If no matches check is applied
	 * 		then this option is ignored.
	 */
	public JsonStringTemplate(String name, String prefix, String suffix,
			String[] contains, boolean containsAll, String[] matches, boolean matchesAll) {
		super(JsonTypes.STRING, name);
		this.prefix = prefix;
		this.suffix = suffix;
		this.contains = contains == null ? new String[0] : contains.clone();
		this.containsAll = containsAll;
		this.matches = matches == null ? new String[0] : matches.clone();
		this.matchesAll = matchesAll;
	}
	
	/**
	 * Utility static method to create a new instance which matches a single string forcefully.
	 * <br>
	 * The returned instance is the equal to the one produced by
	 * {@link #JsonStringTemplate(String, String, String, String[], boolean, String[], boolean) new JsonStringTemplate(name, null, null, null, false, new String[]&#123;regex&#125;, true)}.
	 * 
	 * @param name This template's name, if {@code null} a default one will be used. The name is mainly
	 * 		used for identification.
	 * @param regex The regex that will be used to check the JsonString.
	 * 
	 * @return A new instance as specified.
	 */
	public static JsonStringTemplate matcher(String name, String regex) {
		return new JsonStringTemplate(name, null, null, null, false, new String[]{regex}, true);
	}
	
	@Override
	protected void verify(JsonPrimitive primitive) throws JsonTemplateValidationException {
		String str = primitive.getAsString();
		if (this.prefix != null && !str.startsWith(this.prefix))
			throw this.checker.getExceptionFactory().apply("The JsonString does not start with the expected prefix");
		if (this.suffix != null && !str.endsWith(this.suffix))
			throw this.checker.getExceptionFactory().apply("The JsonString does not end with the expected suffix");
		boolean containAny = this.contains.length == 0;
		for (int i=0;i<this.contains.length;i++) {
			if (!str.contains(Objects.requireNonNull(this.contains[i]))) {
				if (this.containsAll) throw this.checker.getExceptionFactory()
									.apply("The JsonString does not contain the required substring indexed at "+i);
			} else {
				containAny = true;
			}
			
		}
		if (!containAny) throw this.checker.getExceptionFactory()
						.apply("The JsonString does not contain any required substring");
		boolean matchesAny = this.matches.length == 0;
		for (int i=0;i<this.matches.length;i++) {
			if (!str.matches(Objects.requireNonNull(this.matches[i]))) {
				if (this.matchesAll) throw this.checker.getExceptionFactory()
									.apply("The JsonString does not match the required substring indexed at "+i);
			} else {
				matchesAny = true;
			}
		}
		if (!matchesAny) throw this.checker.getExceptionFactory()
						.apply("The JsonString does not match any required substring");
	}

}
