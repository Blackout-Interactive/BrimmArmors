package ema_08_.betterGson.jTemplate;

import java.math.BigDecimal;
import java.util.Objects;

import com.google.gson.*;

import ema_08_.betterGson.GsonNumbers;
import ema_08_.betterGson.JsonTypes;
import ema_08_.betterGson.exceptions.JsonTemplateValidationException;

/**
 * Default implementation of {@link JsonElementTemplate} for {@link JsonTypes#NUMBER JsonNumber}s.
 */
public final class JsonNumberTemplate extends JsonElementTemplate {
	
	private final BigDecimal min, max;
	private final boolean minInclusive, maxInclusive;
	private final GsonNumbers numType;

	/**
	 * Constructs a new template with the type {@link JsonTypes#NUMBER JsonNumber} and the given parameters.
	 * 
	 * @param name This template's name, if {@code null} a default one will be used. The name is mainly
	 * 		used for identification.
	 * @param representationType A {@link GsonNumbers} that define the java number representation in which
	 * 		the number of this template shall fit, see the class' documentation for further information.
	 * 		This parameter shall not be {@code null}.
	 * @param minVal The minimum value this template's number shall have, if {@code null} then no minimum value
	 * 		will be enforced.
	 * @param minInclusive If {@code true} the check will succeed even if the number is equal to the declared minimum
	 * 		value, if {@code false} the number must be greater in order to pass the check. If no minimum value
	 * 		is set, then this option is ignored.
	 * @param maxVal The maximum value this template's number shall have, if {@code null} then no maximum value
	 * 		will be enforced.
	 * @param maxInclusive If {@code true} the check will succeed even if the number is equal to the declared maximum
	 * 		value, if {@code false} the number must be lower in order to pass the check. If no maximum value
	 * 		is set, then this option is ignored.
	 */
	public JsonNumberTemplate(String name, GsonNumbers representationType,
			BigDecimal minVal, boolean minInclusive, BigDecimal maxVal, boolean maxInclusive) {
		super(JsonTypes.NUMBER, name);
		this.numType = Objects.requireNonNull(representationType, "The number type of a number template must be declared");
		this.min = minVal;
		this.max = maxVal;
		this.minInclusive = minInclusive;
		this.maxInclusive = maxInclusive;
	}
	
	/**
	 * Utility static method to create a new instance which clamps a {@link GsonNumbers#DOUBLE double} value
	 * between the given min and max inclusively on both sides.
	 * <br>
	 * The returned instance is the equal to the one produced by
	 * {@link #JsonNumberTemplate(String, GsonNumbers, BigDecimal, boolean, BigDecimal, boolean) new JsonNumberTemplate(name, GsonNumbers.DOUBLE, BigDecimal.valueOf(min), true, BigDecimal.valueOf(max), true)}.
	 * 
	 * @param name This template's name, if {@code null} a default one will be used. The name is mainly
	 * 		used for identification.
	 * @param min The minimum clamp value.
	 * @param max The maximum clamp value.
	 * 
	 * @return A new instance as specified.
	 */
	public static JsonNumberTemplate clampDouble(String name, double min, double max) {
		return new JsonNumberTemplate(name, GsonNumbers.DOUBLE,
				BigDecimal.valueOf(min), true, BigDecimal.valueOf(max), true);
	}
	
	/**
	 * Utility static method to create a new instance which clamps a {@link GsonNumbers#INTEGER integer} value
	 * between the given min and max inclusively on both sides.
	 * <br>
	 * The returned instance is the equal to the one produced by
	 * {@link #JsonNumberTemplate(String, GsonNumbers, BigDecimal, boolean, BigDecimal, boolean) new JsonNumberTemplate(name, GsonNumbers.INTEGER, BigDecimal.valueOf(min), true, BigDecimal.valueOf(max), true)}.
	 * 
	 * @param name This template's name, if {@code null} a default one will be used. The name is mainly
	 * 		used for identification.
	 * @param min The minimum clamp value.
	 * @param max The maximum clamp value.
	 * 
	 * @return A new instance as specified.
	 */
	public static <E extends Exception> JsonNumberTemplate clampInteger(String name, int min, int max) {
		return new JsonNumberTemplate(name, GsonNumbers.INTEGER,
				BigDecimal.valueOf(min), true, BigDecimal.valueOf(max), true);
	}

	@Override
	protected void verify(JsonPrimitive primitive) throws JsonTemplateValidationException {
		this.checker.assertJsonNumber(primitive, this.numType);
		BigDecimal num = new BigDecimal(primitive.getAsString());
		if (this.min != null) {
			int minBound = this.min.compareTo(num);
			if (minBound > 0 || (minBound == 0 && !this.minInclusive))
				throw this.checker.getExceptionFactory()
						.apply("The JsonNumber is less than the minimum allowed value "+this.min.toString());
		}
		if (this.max != null) {
			int maxBound = this.max.compareTo(num);
			if (maxBound < 0 || (maxBound == 0 && !this.maxInclusive))
				throw this.checker.getExceptionFactory()
						.apply("The JsonNumber is more than the maximum allowed value "+this.max.toString());
		}
	}
}
